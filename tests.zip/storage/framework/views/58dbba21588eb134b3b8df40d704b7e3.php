<?php $__env->startSection('content'); ?>
    <div class="flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8">
        <div class="max-w-md w-full space-y-8">
            <div>
                <h2 class="mt-6 text-center text-3xl font-extrabold text-gray-900 bangla-text">
                    সদস্য হিসাবে যোগ দিন
                </h2>
                <p class="mt-2 text-center text-sm text-gray-600 bangla-text">
                    বাংলা কবিতার আসরে আপনার স্বাগতম
                </p>
            </div>

            <form method="POST" action="<?php echo e(route('register')); ?>" class="mt-8 space-y-6">
                <?php echo csrf_field(); ?>

                <!-- Display general errors -->
                <?php if($errors->any()): ?>
                    <div class="bg-red-50 border border-red-200 rounded-md p-4">
                        <div class="flex">
                            <div class="flex-shrink-0">
                                <svg class="h-5 w-5 text-red-400" viewBox="0 0 20 20" fill="currentColor">
                                    <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clip-rule="evenodd" />
                                </svg>
                            </div>
                            <div class="ml-3">
                                <h3 class="text-sm font-medium text-red-800 bangla-text">
                                    রেজিস্ট্রেশনে সমস্যা হয়েছে:
                                </h3>
                                <div class="mt-2 text-sm text-red-700">
                                    <ul class="list-disc list-inside space-y-1">
                                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li class="bangla-text"><?php echo e($error); ?></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>

                <!-- Login Name -->
                <div>
                    <label for="login_name" class="block text-sm font-medium text-gray-700 mb-2 bangla-text">
                        লগইন নাম <span class="text-red-500">*</span>
                    </label>
                    <input id="login_name" type="text" name="login_name" value="<?php echo e(old('login_name')); ?>" required autofocus
                        autocomplete="username"
                        class="block w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                        placeholder="ইংরেজিতে লিখুন (যেমন: john_doe)">
                    <?php $__errorArgs = ['login_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="mt-1 text-sm text-red-600 bangla-text"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <!-- Name in English -->
                <div>
                    <label for="name_english" class="block text-sm font-medium text-gray-700 mb-2 bangla-text">
                        নাম (ইংরেজিতে) <span class="text-red-500">*</span>
                    </label>
                    <input id="name_english" type="text" name="name_english" value="<?php echo e(old('name_english')); ?>" required
                        autocomplete="name"
                        class="block w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                        placeholder="আপনার নাম ইংরেজিতে লিখুন">
                    <?php $__errorArgs = ['name_english'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="mt-1 text-sm text-red-600 bangla-text"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <!-- Name in Bangla -->
                <div>
                    <label for="name_bangla" class="block text-sm font-medium text-gray-700 mb-2 bangla-text">
                        নাম (বাংলায়) <span class="text-red-500">*</span>
                    </label>
                    <input id="name_bangla" type="text" name="name_bangla" value="<?php echo e(old('name_bangla')); ?>" required
                        autocomplete="name"
                        class="block w-full bangla-input border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                        placeholder="আপনার নাম বাংলায় লিখুন...">
                    <?php $__errorArgs = ['name_bangla'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="mt-1 text-sm text-red-600 bangla-text"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <!-- Email Address -->
                <div>
                    <label for="email" class="block text-sm font-medium text-gray-700 mb-2 bangla-text">
                        ইমেইল ঠিকানা <span class="text-red-500">*</span>
                    </label>
                    <input id="email" type="email" name="email" value="<?php echo e(old('email')); ?>" required
                        autocomplete="username"
                        class="block w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="mt-1 text-sm text-red-600 bangla-text"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <!-- Password -->
                <div>
                    <label for="password" class="block text-sm font-medium text-gray-700 mb-2 bangla-text">
                        পাসওয়ার্ড <span class="text-red-500">*</span>
                    </label>
                    <input id="password" type="password" name="password" required autocomplete="new-password"
                        class="block w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="mt-1 text-sm text-red-600 bangla-text"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <!-- Confirm Password -->
                <div>
                    <label for="password_confirmation" class="block text-sm font-medium text-gray-700 mb-2 bangla-text">
                        পাসওয়ার্ড নিশ্চিত করুন <span class="text-red-500">*</span>
                    </label>
                    <input id="password_confirmation" type="password" name="password_confirmation" required
                        autocomplete="new-password"
                        class="block w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
                </div>

                <!-- Input Method Selection -->
                <?php if (isset($component)) { $__componentOriginal2ef321cda33b655cedbc30879e338bdb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2ef321cda33b655cedbc30879e338bdb = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.keyboard-switcher','data' => ['name' => 'input_method','value' => ''.e(old('input_method', 'avro')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('keyboard-switcher'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'input_method','value' => ''.e(old('input_method', 'avro')).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2ef321cda33b655cedbc30879e338bdb)): ?>
<?php $attributes = $__attributesOriginal2ef321cda33b655cedbc30879e338bdb; ?>
<?php unset($__attributesOriginal2ef321cda33b655cedbc30879e338bdb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2ef321cda33b655cedbc30879e338bdb)): ?>
<?php $component = $__componentOriginal2ef321cda33b655cedbc30879e338bdb; ?>
<?php unset($__componentOriginal2ef321cda33b655cedbc30879e338bdb); ?>
<?php endif; ?>

                <!-- Has Other Account -->
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2 bangla-text">
                        আপনার কি অন্য কোন অ্যাকাউন্ট আছে? <span class="text-red-500">*</span>
                    </label>
                    <div class="space-y-2">
                        <div class="flex items-center">
                            <input id="has_other_account_no" type="radio" name="has_other_account" value="no"
                                <?php echo e(old('has_other_account', 'no') == 'no' ? 'checked' : ''); ?> required
                                class="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300">
                            <label for="has_other_account_no" class="ml-2 block text-sm text-gray-700 bangla-text">
                                না
                            </label>
                        </div>
                        <div class="flex items-center">
                            <input id="has_other_account_yes" type="radio" name="has_other_account" value="yes"
                                <?php echo e(old('has_other_account') == 'yes' ? 'checked' : ''); ?>

                                class="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300">
                            <label for="has_other_account_yes" class="ml-2 block text-sm text-gray-700 bangla-text">
                                হ্যাঁ
                            </label>
                        </div>
                        <div class="flex items-center">
                            <input id="has_other_account_inactive" type="radio" name="has_other_account" value="inactive"
                                <?php echo e(old('has_other_account') == 'inactive' ? 'checked' : ''); ?>

                                class="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300">
                            <label for="has_other_account_inactive" class="ml-2 block text-sm text-gray-700 bangla-text">
                                ছিল কিন্তু এখন নিষ্ক্রিয়
                            </label>
                        </div>
                    </div>
                    <?php $__errorArgs = ['has_other_account'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="mt-1 text-sm text-red-600 bangla-text"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <!-- Terms and Conditions -->
                <div class="flex items-center">
                    <input id="terms_accepted" type="checkbox" name="terms_accepted" value="1"
                        <?php echo e(old('terms_accepted') ? 'checked' : ''); ?> required
                        class="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded">
                    <label for="terms_accepted" class="ml-2 block text-sm text-gray-700 bangla-text">
                        আমি <a href="#" class="text-blue-600 hover:text-blue-500">শর্তাবলী</a> এবং <a href="#"
                            class="text-blue-600 hover:text-blue-500">গোপনীয়তা নীতি</a> মেনে চলতে সম্মত
                    </label>
                    <?php $__errorArgs = ['terms_accepted'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="mt-1 text-sm text-red-600 bangla-text"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="flex items-center justify-between">
                    <a class="text-sm text-blue-600 hover:text-blue-500 bangla-text" href="<?php echo e(route('login')); ?>">
                        ইতিমধ্যে অ্যাকাউন্ট আছে? লগ ইন করুন
                    </a>

                    <button type="submit"
                        class="bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded bangla-text">
                        রেজিস্ট্রেশন করুন
                    </button>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.bangla-app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Rakib\Outside\bangla-kobita\resources\views/auth/register.blade.php ENDPATH**/ ?>